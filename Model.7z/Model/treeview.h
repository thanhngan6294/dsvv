#ifndef TREEVIEW_H
#define TREEVIEW_H
#include <QAbstractTableModel>
#include <QAbstractItemModel>
#include <QStringList>
#include <QVariant>
#include <delegate.h>
class TreeView : public QAbstractItemModel
{
    Q_OBJECT

public:
    TreeView(int rows = 1, QObject *parent = 0);

    int rowCount(const QModelIndex &parent = QModelIndex()) const;
    //int columnCount(const QModelIndex &parent = QModelIndex()) const;
    QVariant data(const QModelIndex &index, int role) const;
    Qt::ItemFlags flags(const QModelIndex &index) const;
    bool setData(const QModelIndex &index, const QVariant &value,
                 int role = Qt::EditRole);

    bool insertRows(int position, int rows, const QModelIndex &parent = QModelIndex());
   // bool insertColumns(int position, int columns, const QModelIndex &parent = QModelIndex());
    bool removeRows(int position, int rows, const QModelIndex &parent = QModelIndex());
    //bool removeColumns(int position, int columns, const QModelIndex &parent = QModelIndex());

private:
    QList<QStringList> rowList;
};
#endif // TREEVIEW_H
