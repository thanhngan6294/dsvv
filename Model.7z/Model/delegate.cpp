#include "delegate.h"
#include <QComboBox>

ComboBoxDeleGate::ComboBoxDeleGate(QObject *parent)
    : QStyledItemDelegate(parent)
{
}

QWidget *ComboBoxDeleGate::createEditor(QWidget *parent,
    const QStyleOptionViewItem &/* option */,
    const QModelIndex &/* index */) const
{

    QComboBox *editor = new QComboBox(parent);
    editor->addItem("Intel");
    editor->addItem("Motorola");
    editor->setFrame(false);

    return editor;
}

//void ComboBoxDeleGate::setEditorData(QWidget *editor,
//                                    const QModelIndex &index) const
//{
//    int value = index.model()->data(index, Qt::EditRole).toInt();

//    QComboBox *comboBox = static_cast<QComboBox*>(editor);
//    //comboBox->setValue(value);
//}

//void SpinBoxDelegate::setModelData(QWidget *editor, QAbstractItemModel *model,
//                                   const QModelIndex &index) const
//{
//    QComboBox *comboBox = static_cast<QComboBox*>(editor);
//    //comboBox->interpretText();
//    //int value = comboBox->value();

//    //model->setData(index, value, Qt::EditRole);
//}

void ComboBoxDeleGate::updateEditorGeometry(QWidget *editor,
    const QStyleOptionViewItem &option, const QModelIndex &/* index */) const
{
    editor->setGeometry(option.rect);
}
