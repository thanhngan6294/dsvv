#include <QApplication>
#include <QItemSelection>
#include <QItemSelectionModel>
#include <QTableView>
#include <delegate.h>
#include "model.h"
#include <QHeaderView>
#include <treeview.h>
#include <QHBoxLayout>
#include <QWidget>
int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    QWidget *mainlayout = new QWidget;
    TableModel *model = new TableModel(8, 4, &app);
    //TreeView *treeview = new TreeView;
    QTableView *table = new QTableView(0);
    //QHBoxLayout *layout = new QHBoxLayout;
    //layout->addWidget(table);
    //layout->addWidget(treeview);
    //layout->setStretchFactor(treeview, 2);
    //layout->setStretchFactor(table, 7);
    //mainlayout->setLayout(layout);
    table->setModel(model);
    //treeview->
    ComboBoxDeleGate delegate;
    table->setItemDelegate(&delegate);
    table->horizontalHeader()->setStretchLastSection(true);
    table->verticalHeader()->setVisible(false);
    table->setWindowTitle("Selected items in a table model");
    table->show();
    table->resize(460, 280);
    return app.exec();
}
